
import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Table,
  Button,
  Modal,
  message,
  Input,
  Space,
  Select,
} from "antd";
import DefaultLayout from "../components/DefaultLayout";
import { useNavigate } from "react-router-dom";

const { Option } = Select;

function QuickAccess() {
  const [customerName, setCustomerName] = useState("");
  const [bills, setBills] = useState([]);
  const [selectedBill, setSelectedBill] = useState(null);
  const [editedItems, setEditedItems] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [allItems, setAllItems] = useState([]);
  const navigate = useNavigate();

  const [subTotal, setSubTotal] = useState(0);
  const [exactTotal, setExactTotal] = useState(0);
  const [finalTotal, setFinalTotal] = useState(0);
  const [roundOff, setRoundOff] = useState(0);

  useEffect(() => {
    const newSubTotal = editedItems.reduce(
      (acc, item) => acc + item.quantity * item.price,
      0
    );
    setSubTotal(newSubTotal);

    const calculatedExactTotal = newSubTotal * 1.18;
    const calculatedFinalTotal = Math.round(calculatedExactTotal);
    const calculatedRoundOff = calculatedFinalTotal - calculatedExactTotal;

    setExactTotal(calculatedExactTotal);
    setFinalTotal(calculatedFinalTotal);
    setRoundOff(calculatedRoundOff);
  }, [editedItems]);

  useEffect(() => {
    axios
      .get("/api/items/get-item")
      .then((res) => setAllItems(res.data))
      .catch((err) => {
        console.error("Error fetching items:", err);
        message.error("Failed to load item list.");
      });
  }, []);

  const fetchBills = async () => {
    try {
      const res = await axios.get(
        `/api/quickbilling/last-5/${encodeURIComponent(customerName)}`
      );
      setBills(res.data);
    } catch (err) {
      console.error("Error fetching bills:", err);
      message.error("Failed to fetch bills.");
    }
  };

  const openEditModal = (bill) => {
    setSelectedBill(bill);
    setEditedItems(bill.cartItems || []);
    setIsModalOpen(true);
  };

  const handleItemUpdate = (index, field, value) => {
    const updated = [...editedItems];

    if (field === "name") {
      updated[index].name = value;
      const selected = allItems.find((item) => item.name === value);
      updated[index].price = selected?.price || 0;
      updated[index].taxPercent = selected?.taxPercent || 0;
    } else {
      updated[index][field] =
        field === "quantity" || field === "price" ? Number(value) : value;
    }

    setEditedItems(updated);
  };

  const handleItemDelete = (index) => {
    const updated = [...editedItems];
    updated.splice(index, 1);
    setEditedItems(updated);
  };

  const addNewItem = () => {
    setEditedItems([...editedItems, { name: "", quantity: 1, price: 0 }]);
  };

  const handleGenerateBill = async () => {
    if (
      editedItems.some(
        (item) => !item.name || item.quantity <= 0 || item.price < 0
      )
    ) {
      return message.error(
        "Please ensure all items have valid name, quantity, and price."
      );
    }

    try {
      const cartItems = editedItems.map((item) => {
        const match = allItems.find((i) => i.name === item.name);
        return {
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          taxPercent: match?.taxPercent || 0,
          discountPercent: 0,
        };
      });

      let subTotal = 0;
      let taxAmount = 0;
      
      cartItems.forEach((item) => {
        const rateWithoutTax = item.price / (1 + item.taxPercent / 100);
        const itemTotal = rateWithoutTax * item.quantity;
        subTotal += itemTotal;

        const itemTax = (rateWithoutTax * item.taxPercent) / 100 * item.quantity;
        taxAmount += itemTax;
      });

      const afterDiscount = subTotal; // No discount applied in Quick Access
      const calculatedExactTotal = afterDiscount + taxAmount;
      const finalTotal = Math.round(calculatedExactTotal);
      const roundOff = finalTotal - calculatedExactTotal;

      const payload = {
        cartItems,
        customerName: selectedBill.customerName || "QuickAccess User",
        customerNumber: selectedBill.customerNumber || "0000000000",
        paymentMode: selectedBill.paymentMode || "QuickAccess",
        subTotal: subTotal.toFixed(2),
        afterDiscount: afterDiscount.toFixed(2),
        taxAmount: taxAmount.toFixed(2),
        roundOff: roundOff.toFixed(2),
        totalAmount: finalTotal.toFixed(2),
      };

      await axios.post(`/api/quickbilling/clone/${selectedBill._id}`, payload);

      message.success("New bill generated successfully!");
      setIsModalOpen(false);
      navigate("/bills");
    } catch (err) {
      console.error("Error generating bill:", err.message, err);
      message.error("Failed to generate new bill.");
    }
  };

  const columns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      render: (val) => new Date(val).toLocaleDateString(),
    },
    {
      title: "Customer",
      dataIndex: "customerName",
    },
    {
      title: "Mobile",
      dataIndex: "customerNumber",
    },
    {
      title: "Total",
      dataIndex: "totalAmount",
    },
    {
      title: "Action",
      render: (_, record) => (
        <Button type="link" onClick={() => openEditModal(record)}>
          Edit & Clone
        </Button>
      ),
    },
  ];

  const uniqueItems = Array.from(
    new Map(allItems.map((item) => [item.name, item])).values()
  ).filter((item) => item.stockQuantity > 0);

  return (
    <DefaultLayout>
      <h3>🔁 Quick Access - Reuse Past Bills</h3>
      <Space className="mb-3">
        <Input
          placeholder="Enter Customer Name"
          value={customerName}
          onChange={(e) => setCustomerName(e.target.value)}
        />
        <Button type="primary" onClick={fetchBills}>
          Search
        </Button>
      </Space>

      <Table
        dataSource={bills}
        columns={columns}
        rowKey={(record) => record._id}
        bordered
        pagination={false}
      />

      <Modal
        open={isModalOpen}
        title="🛒 Edit Bill Items"
        onCancel={() => setIsModalOpen(false)}
        onOk={handleGenerateBill}
        okText="Generate Bill"
        width={800}
      >
        {editedItems.map((item, index) => (
          <div className="d-flex mb-2 gap-2" key={index}>
            <Select
              showSearch
              style={{ width: 200 }}
              placeholder="Select Item"
              value={item.name}
              onChange={(value) => handleItemUpdate(index, "name", value)}
              filterOption={(input, option) =>
                option.children.toLowerCase().includes(input.toLowerCase())
              }
            >
              {uniqueItems.map((i) => (
                <Option key={i.name} value={i.name}>
                  {i.name} ({i.stockQuantity} left)
                </Option>
              ))}
            </Select>

            <Input
              type="number"
              placeholder="Qty"
              value={item.quantity}
              onChange={(e) =>
                handleItemUpdate(index, "quantity", e.target.value)
              }
            />

            <Input
              placeholder="Amount"
              value={(item.quantity * item.price).toFixed(2)}
              disabled
            />

            <Button danger onClick={() => handleItemDelete(index)}>
              Delete
            </Button>
          </div>
        ))}

        <p className="text-end fw-bold mt-2">
          Subtotal: ₹{subTotal.toFixed(2)} <br />
          Tax (18%): ₹{(subTotal * 0.18).toFixed(2)} <br />
          <span style={{ textDecoration: "line-through", color: "#888" }}>
            Exact Total: ₹{exactTotal.toFixed(2)}
          </span>{" "}
          <br />
          Round Off: ₹{roundOff.toFixed(2)} <br />
          <strong style={{ fontSize: "1.1rem" }}>
            Final Total: ₹{finalTotal}
          </strong>
        </p>

        <Button type="dashed" onClick={addNewItem} block>
          ➕ Add Item
        </Button>
      </Modal>
    </DefaultLayout>
  );
}

export default QuickAccess;

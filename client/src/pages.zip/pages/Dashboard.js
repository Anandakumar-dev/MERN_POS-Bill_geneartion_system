import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  Tooltip, XAxis, YAxis, ResponsiveContainer, Legend
} from "recharts";
import DefaultLayout from "../components/DefaultLayout";
// import { Table, Dropdown, Button } from "antd";
import { Dropdown, Button } from "antd";
import { MenuOutlined } from "@ant-design/icons";
import {
  exportChartAsPDF,
  exportTableAsPDF,
  exportTableAsCSV
} from "../utils/exportUtils";
import "./Dashboard.css";




const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#AA00FF"];

const Dashboard = () => {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    document.body.classList.toggle("dark-mode", darkMode);
  }, [darkMode]);


  const [summary, setSummary] = useState(null);

  const [chartType, setChartType] = useState("bar");
  const [selectedPeriod, setSelectedPeriod] = useState("Today");

  const [itemSalesChartType, setItemSalesChartType] = useState("bar");
  const [itemSalesPeriod, setItemSalesPeriod] = useState("Today");

  const [inventoryChartType, setInventoryChartType] = useState("bar");
    const [inventoryPeriod, setInventoryPeriod] = useState("Today");

  const [lowStockChartType, setLowStockChartType] = useState("bar");
  const [lowStockPeriod, setLowStockPeriod] = useState("Today");

    // const [selectedPeriod, setSelectedPeriod] = useState("LastYear");
  // const [itemSalesPeriod, setItemSalesPeriod] = useState("CurrentMonth");
  // const [inventoryPeriod, setInventoryPeriod] = useState("CurrentMonth");
    // const [lowStockPeriod, setLowStockPeriod] = useState("CurrentMonth");

  const [topItems, setTopItems] = useState([]);
  const [itemSales, setItemSales] = useState([]);
  const [inventory, setInventory] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [summaryRes, chartRes, itemSalesRes, inventoryRes] = await Promise.all([
          axios.get("/api/dashboard/dashboard-summary"),
          axios.get(`/api/dashboard/dashboard-data?period=${selectedPeriod}`),
          axios.get(`/api/dashboard/item-wise-sales?period=${itemSalesPeriod}`),
          axios.get(`/api/dashboard/inventory-stock?period=${inventoryPeriod}`)
        ]);
        setSummary(summaryRes.data);
        setTopItems(chartRes.data.topItems || []);
        setItemSales(itemSalesRes.data.itemWiseSales || []);
        setInventory(inventoryRes.data || []);
      } catch (error) {
        console.error("Dashboard fetch error:", error);
      }
    };
    fetchData();
  }, [selectedPeriod, itemSalesPeriod, inventoryPeriod, lowStockPeriod]);

  const renderChart = (data, key, type) => {
    if (data.length === 0) return <div className="text-muted">⚠ No data available</div>;
    if (type === "bar") {
      return <BarChart data={data}><XAxis dataKey="name" /><YAxis /><Tooltip /><Legend /><Bar dataKey={key} fill="#00C49F" /></BarChart>;
    }
    if (type === "line") {
      return <LineChart data={data}><XAxis dataKey="name" /><YAxis /><Tooltip /><Legend /><Line type="monotone" dataKey={key} stroke="#8884d8" /></LineChart>;
    }
    if (type === "pie") {
      return (
        <PieChart>
          <Pie data={data} dataKey={key} nameKey="name" cx="50%" cy="50%" outerRadius={130} label>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      );
    }
    return null;
  };

  const exportMenu = (chartId, columns, tableData, tableName) => (
    {
      items: [
        {
          key: 'chartPdf',
          label: <span onClick={() => exportChartAsPDF(chartId, `${tableName}_Chart`)}>Export Chart as PDF</span>
        },
        {
          key: 'tablePdf',
          label: <span onClick={() => exportTableAsPDF(columns, tableData, `${tableName}_Table`)}>Export Table as PDF</span>
        },
        {
          key: 'csv',
          label: <span onClick={() => exportTableAsCSV( columns, tableData, `${tableName}_Table`)}>Export Table as CSV</span>
        }
      ]
    }
  );

  const itemSalesColumns = [
    { title: "Item Name", dataIndex: "name", key: "name" },
    { title: "Quantity Sold", dataIndex: "quantity", key: "quantity" },
    { title: "Revenue (₹)", dataIndex: "revenue", key: "revenue" },
  ];

  const inventoryColumns = [
    { title: "Item", dataIndex: "name", key: "name" },
    { title: "Category", dataIndex: "category", key: "category" },
    { title: "Price (₹)", dataIndex: "price", key: "price" },
    { title: "Stock Qty", dataIndex: "stockQuantity", key: "stockQuantity" },
  ];

  const lowStockColumns = [
    { title: "Item", dataIndex: "name", key: "name" },
    { title: "Stock Qty", dataIndex: "stockQuantity", key: "stockQuantity" },
  ];

  if (!summary) return <DefaultLayout><div className="container mt-4">Loading...</div></DefaultLayout>;

  return (
    <DefaultLayout>
      <div className="d-flex justify-content-end mb-1">
        <button
          className="btn btn-sm btn-dark"
          onClick={() => setDarkMode(prev => !prev)}
        >
          {darkMode ? "☀ Light Mode" : "🌙 Dark Mode"}
        </button>
      </div>
      <div className="dashboard-container">
        {/* 🔢 Summary Cards */}
        <div className="row my-1">
          <div className="col-md-3"><div className="summary-card sales">💰 Total Sales: ₹{summary.totalSales}</div></div>
          <div className="col-md-3"><div className="summary-card purchase">📦 Total Purchase: ₹{summary.totalPurchase}</div></div>
          <div className="col-md-3"><div className="summary-card items">📋 Total Items: {summary.totalItems}</div></div>
          <div className="col-md-3"><div className="summary-card stock">🏷 Stock Value: ₹{summary.totalStockValue}</div></div>
        </div>

        {/* 🧾 Item-wise Sales and 📦 Inventory Stock */}
        <div className="row section-container">
          {/* Item-wise Sales */}
          <div className="col-md-6">
            <h4 className="d-flex justify-content-around align-items-center mb-2">🧾 Item-wise Sales</h4>
            <div className="d-flex justify-content-around align-items-center mb-2">
              <div className="d-flex gap-2">
                <select className="form-select" value={itemSalesChartType} onChange={(e) => setItemSalesChartType(e.target.value)}>
                  <option value="bar">Bar</option>
                  <option value="line">Line</option>
                  <option value="pie">Pie</option>
                </select>
                <select className="form-select" value={itemSalesPeriod} onChange={(e) => setItemSalesPeriod(e.target.value)}>
                  <option value="Today">Today</option>
                  <option value="LastYear">Last Year</option>
                  <option value="LastThreeMonths">Last Three Months</option>
                  <option value="CurrentFinancialYear">Current Financial Year</option>
                  <option value="LastMonth">Last Month</option>
                  <option value="CurrentMonth">Current Month</option>
                  <option value="LastWeek">Last Week</option>
                </select>
                <Dropdown menu={exportMenu("itemSalesChart", itemSalesColumns, itemSales, "ItemSales")} trigger={['click']}>
                  <Button icon={<MenuOutlined />} className="export-dropdown" />
                </Dropdown>
              </div>
            </div>
            <ResponsiveContainer id="itemSalesChart" width="100%" height={250}>
              {renderChart(itemSales, "quantity", itemSalesChartType)}
            </ResponsiveContainer>
            {/* <Table dataSource={itemSales} columns={itemSalesColumns} rowKey="name" pagination={false} /> */}
          </div>

          {/* Inventory Stock */}
          <div className="col-md-6">
            <h4 className="d-flex justify-content-around align-items-center mb-2">📦 Inventory Stock</h4>
            <div className="d-flex justify-content-between align-items-center mb-2">
              <div className="d-flex gap-2">
                <select className="form-select" value={inventoryChartType} onChange={(e) => setInventoryChartType(e.target.value)}>
                  <option value="bar">Bar</option>
                  <option value="line">Line</option>
                  <option value="pie">Pie</option>
                </select>
                <select className="form-select" value={inventoryPeriod} onChange={(e) => setInventoryPeriod(e.target.value)}>
                  <option value="Today">Today</option>
                  <option value="LastYear">Last Year</option>
                  <option value="LastThreeMonths">Last Three Months</option>
                  <option value="CurrentFinancialYear">Current Financial Year</option>
                  <option value="LastMonth">Last Month</option>
                  <option value="CurrentMonth">Current Moncdth</option>
                  <option value="LastWeek">Last Week</option>
                </select>
                <Dropdown menu={exportMenu("inventoryChart", inventoryColumns, inventory, "Inventory")} trigger={['click']}>
                  <Button icon={<MenuOutlined />} className="export-dropdown" />
                </Dropdown>
              </div>
            </div>
            <ResponsiveContainer id="inventoryChart" width="100%" height={250}>
              {renderChart(inventory.map(i => ({ name: i.name, stockQuantity: i.stockQuantity })), "stockQuantity", inventoryChartType)}
            </ResponsiveContainer>
            {/* <Table dataSource={inventory} columns={inventoryColumns} rowKey="_id" pagination={false} /> */}
          </div>
        </div>

        {/* 📊 Sales Chart and 🚨 Low Stock */}
        <div className="row section-container">
          {/* Sales Chart */}
          <div className="col-md-6">
            <h4 className="d-flex justify-content-around align-items-center mb-2">📊 Sales Chart</h4>
            <div className="d-flex justify-content-between align-items-center mb-2">
              <div className="d-flex gap-2">
                <select className="form-select" value={chartType} onChange={(e) => setChartType(e.target.value)}>
                  <option value="bar">Bar</option>
                  <option value="line">Line</option>
                  <option value="pie">Pie</option>
                </select>
                <select className="form-select" value={selectedPeriod} onChange={(e) => setSelectedPeriod(e.target.value)}>
                  <option value="Today">Today</option>
                  <option value="LastYear">Last Year</option>
                  <option value="LastThreeMonths">Last Three Months</option>
                  <option value="CurrentFinancialYear">Current Financial Year</option>
                  <option value="LastMonth">Last Month</option>
                  <option value="CurrentMonth">Current Month</option>
                  <option value="LastWeek">Last Week</option>
                </select>
                <Dropdown menu={exportMenu("salesChart", topItems, "Sales")} trigger={['click']}>
                  <Button icon={<MenuOutlined />} className="export-dropdown" />
                </Dropdown>
              </div>
            </div>
            <ResponsiveContainer id="salesChart" width="100%" height={250}>
              {renderChart(topItems, "quantity", chartType)}
            </ResponsiveContainer>
          </div>

          {/* Low Stock */}
          <div className="col-md-6">
            <h4 className="d-flex justify-content-around align-items-center mb-2">🚨 Low Stock (Qty less then 10)</h4>
            <div className="d-flex justify-content-between align-items-center mb-2">
              <div className="d-flex gap-2">
                <select className="form-select" value={lowStockChartType} onChange={(e) => setLowStockChartType(e.target.value)}>
                  <option value="bar">Bar</option>
                  <option value="line">Line</option>
                  <option value="pie">Pie</option>
                </select>
                <select className="form-select" value={lowStockPeriod} onChange={(e) => setLowStockPeriod(e.target.value)}>
                  <option value="Today">Today</option>
                  <option value="LastYear">Last Year</option>
                  <option value="LastThreeMonths">Last Three Months</option>
                  <option value="CurrentFinancialYear">Current Financial Year</option>
                  <option value="LastMonth">Last Month</option>
                  <option value="CurrentMonth">Current Month</option>
                  <option value="LastWeek">Last Week</option>
                </select>
                <Dropdown menu={exportMenu("lowStockChart", lowStockColumns, inventory.filter(i => i.stockQuantity < 5), "LowStock")} trigger={['click']}>
                  <Button icon={<MenuOutlined />} className="export-dropdown" />
                </Dropdown>
              </div>
            </div>
            <ResponsiveContainer id="lowStockChart" width="100%" height={250}>
              {renderChart(
                inventory.filter(i => i.stockQuantity < 10).map(i => ({ name: i.name, stockQuantity: i.stockQuantity })),
                "stockQuantity",
                lowStockChartType
              )}
            </ResponsiveContainer>
            {/* <Table
              dataSource={inventory.filter(i => i.stockQuantity < 5)}
              columns={lowStockColumns}
              rowKey="_id"
              pagination={false}
            /> */}
          </div>
        </div>
      </div>
    </DefaultLayout>
  );
};

export default Dashboard;

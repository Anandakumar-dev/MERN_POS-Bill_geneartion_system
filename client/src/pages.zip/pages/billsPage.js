import React, { useEffect, useRef, useState, useCallback } from "react";
import DefaultLayout from "../components/DefaultLayout";
import axios from "axios";
import { EyeOutlined, DeleteOutlined } from "@ant-design/icons";
import { Button, Modal, Table, Popconfirm, message } from "antd";
import { useReactToPrint } from "react-to-print";

function Bills() {
  const componentRef = useRef();
  const [billsData, setBillsData] = useState([]);
  const [printBillModalVisibility, setPrintBillModalVisibilty] = useState(false);
  const [selectedBill, setSelectedBill] = useState(null);

  const getAllBills = useCallback(async () => {
    const response = await axios.get("/api/bills/get-bills");
    setBillsData(response.data);
    console.log("values", response.data)

  }, []);

  useEffect(() => {
    getAllBills();

  }, [getAllBills]);

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  const columns = [
    {
      title: "Id",
      dataIndex: "_id",
    },
    {
      title: "Customer",
      dataIndex: "customerName",
    },
    {
      title: "Tax",
      dataIndex: "tax",
    },
    {
      title: "Total",
      dataIndex: "totalAmount",
    },
    {
      title: "Actions",
      dataIndex: "_id",
      render: (id, record) => (
        <div className="d-flex">
          <EyeOutlined
            className="mx-2"
            onClick={() => {
              setSelectedBill(record);
              setPrintBillModalVisibilty(true);
            }}
          />
          <Popconfirm
            title="Are you sure to delete this bill?"
            onConfirm={() => handleDelete(record._id)}
            okText="Yes"
            cancelText="No"
          >
            <DeleteOutlined
              className="mx-2"
              style={{ color: "red", fontSize: "18px", cursor: "pointer" }}
            // onClick={() => handleDelete(record._id)}
            />
          </Popconfirm>
        </div>
      ),
    },
  ];

  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/bills/delete-bill/${id}`);
      message.success("Bill deleted successfully");
      getAllBills(); // refresh list
    } catch (error) {
      console.error(error);
      message.error("Failed to delete bill");
    }
  };


  return (
    <DefaultLayout>
      <div className="d-flex justify-content-between">
        <h3>All Bills</h3>
      </div>
      <Table columns={columns} dataSource={billsData} bordered />

      {printBillModalVisibility && selectedBill && (
        <Modal
          onCancel={() => setPrintBillModalVisibilty(false)}
          open={printBillModalVisibility}
          title="Invoice Preview"
          footer={false}
          width={800}
        >
          <div className="p-3" ref={componentRef} style={{ fontFamily: "monospace" }}>
            <div style={{ textAlign: "center", marginBottom: 10 }}>
              <h2>Corewize Solutions</h2>
              <div>(UNIT OF IT Tech solutions)</div>
              <div style={{ fontSize: 12 }}>
                11/20, SUBRAMANIYA GARDEN STREET, TRIPLICANE<br />
                Near. Rathna cafe<br />
                Ph: 044-43588000 Mob: 6383063273<br />
                GSTIN: AA3307250517157
              </div>
            </div>

            <hr />
            <div style={{ fontSize: "13px", marginBottom: 10 }}>
              <div>Bill No : {selectedBill.invoiceNumber || selectedBill._id}</div>
              <div>Date : {new Date(selectedBill.createdAt).toLocaleDateString()} &nbsp;
                Time : {new Date(selectedBill.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
              <div>Customer : {selectedBill.customerName}</div>
              <div>Phone : {selectedBill.customerNumber}</div>
            </div>
            <hr />

            <table width="100%" style={{ fontSize: "13px" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid black" }}>
                  <th align="center">S.No</th>
                  <th align="center">Name</th>
                  <th align="center">Rate(incl tax)</th>
                  <th align="center">Rate</th>
                  <th align="center">GST</th>
                  <th align="center">Qty</th>
                  <th align="center">Amount</th>
                </tr>
              </thead>
              <tbody>
                {selectedBill.cartItems.map((item, idx) => {
                  const basePrice = (item.price * 100) / (100 + item.taxPercent || 0);
                  const discountPercent = selectedBill.discountPercent || 0;
                  const taxPercent = item.taxPercent || 0;
                  const quantity = item.quantity || 0;

                  const wtrate = item.price / ((taxPercent + 100) / 100);
                  const wtvalue = wtrate * (discountPercent / 100)
                  const wttotal = wtrate - wtvalue

                  const discounted = basePrice - (basePrice * discountPercent) / 100;
                  const taxAmount = (discounted * taxPercent) / 100;
                  const finalPricePerUnit = discounted + taxAmount;
                  const totalAmount = finalPricePerUnit * quantity;
                  return (
                    <tr key={idx}>

                      <td align="left">{idx + 1}</td>
                      <td align="left">{item.name}</td>
                      <td align="left">₹{item.price.toFixed(2)}</td>
                      <td align="left">₹{wttotal.toFixed(2)}</td>
                      <td align="left">{item.taxPercent}%</td>
                      <td align="left">{item.quantity}</td>
                      <td align="left">₹{!isNaN(totalAmount) ? totalAmount.toFixed(2) : "0.00"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <hr />

            <div style={{ fontSize: "13px" }}>

              <div>Qty : {selectedBill.cartItems.reduce((sum, item) => sum + item.quantity, 0)}</div>
              <div>Sub Total : ₹{(selectedBill.subTotal || 0).toFixed(2)}</div>
              <div>
                Discount ({((selectedBill.subTotal && selectedBill.afterDiscount) ?
                  (100 * (1 - selectedBill.afterDiscount / selectedBill.subTotal)).toFixed(0) : 0)}%) :
                ₹{(selectedBill.subTotal && selectedBill.afterDiscount
                  ? (selectedBill.subTotal - selectedBill.afterDiscount).toFixed(2)
                  : "0.00")}
              </div>

              <div style={{ fontWeight: "bold", fontSize: "16px" }}>
                After Discount : ₹{(selectedBill.afterDiscount || (selectedBill.subTotal || 0)).toFixed(2)}
              </div>
              <div>GST : ₹{(selectedBill.tax || 0).toFixed(2)}</div>
              {/* <div style={{ fontWeight: "bold", fontSize: "16px" }}>
                Grand Total : ₹{(selectedBill.totalAmount || 0).toFixed(2)}
              </div> */}
              <div>Round Off : ₹{(selectedBill.roundOff || 0).toFixed(2)}</div>
              <div style={{ fontWeight: "bold", fontSize: "16px" }}>
                Grand Total : ₹{(selectedBill.afterDiscount || (selectedBill.subTotal || 0)).toFixed(2)}
              </div>
            </div>
            <hr />

            <table width="100%" style={{ fontSize: "13px", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th>GST%</th>
                  <th>Tax Value</th>
                  <th>CGST%</th>
                  <th>CGST</th>
                  <th>SGST%</th>
                  <th>SGST</th>
                </tr>
              </thead>
              <tbody>
                {(() => {
                  const groupedTaxes = {};
                  const items = selectedBill?.cartItems || [];

                  items.forEach((item) => {
                    const quantity = Number(item.quantity) || 0;
                    const price = Number(item.price) || 0;
                    const discountPercent = Number(selectedBill.discountPercent) || 0;
                    const taxPercent = Number(item.taxPercent) || 0;

                    const wtrate = item.price / ((taxPercent + 100) / 100);
                    const wtvalue = wtrate * (discountPercent / 100)
                    const wttotal = wtrate - wtvalue

                    const taxAmount = (wttotal * taxPercent) / 100;

                    const grossAmount = price * quantity;
                    // const discountAmount = (grossAmount * discountPercent) / 100;
                    // const taxableAmount = grossAmount - discountAmount;
                    // const taxAmount = (taxableAmount * taxPercent) / 100;

                    if (!groupedTaxes[taxPercent]) {
                      groupedTaxes[taxPercent] = {
                        taxable: 0,
                        taxAmount: 0,
                        cgstPercent: taxPercent / 2,
                        sgstPercent: taxPercent / 2,
                      };
                    }

                    // groupedTaxes[taxPercent].taxable += taxableAmount;
                    groupedTaxes[taxPercent].taxable += wttotal * quantity;
                    groupedTaxes[taxPercent].taxAmount += taxAmount * quantity;
                  });

                  const totalTaxable = Object.values(groupedTaxes).reduce(
                    (sum, t) => sum + t.taxable,
                    0
                  );
                  const totalCGST = Object.values(groupedTaxes).reduce(
                    (sum, t) => sum + t.taxAmount / 2,
                    0
                  );
                  const totalSGST = totalCGST;

                  return (
                    <>
                      {Object.entries(groupedTaxes)
                        .sort(([a], [b]) => Number(a) - Number(b))
                        .map(([taxPercent, data], idx) => {
                          const halfTax = data.taxAmount / 2;
                          return (
                            <tr key={idx}>
                              <td>{taxPercent}%</td>
                              <td>₹{data.taxable.toFixed(2)}</td>
                              <td>{data.cgstPercent.toFixed(2)}%</td>
                              <td>₹{halfTax.toFixed(2)}</td>
                              <td>{data.sgstPercent.toFixed(2)}%</td>
                              <td>₹{halfTax.toFixed(2)}</td>
                            </tr>
                          );
                        })}
                      <tr style={{ fontWeight: "bold" }}>
                        <td>Total</td>
                        <td>₹{totalTaxable.toFixed(2)}</td>
                        <td></td>
                        <td>₹{totalCGST.toFixed(2)}</td>
                        <td></td>
                        <td>₹{totalSGST.toFixed(2)}</td>
                      </tr>
                    </>
                  );
                })()}
              </tbody>
            </table>

            <hr />
            <div style={{ textAlign: "center" }}>
              *** THANK YOU VISIT AGAIN ***
            </div>
          </div>

          <div className="d-flex justify-content-end mt-2">
            <Button type="primary" onClick={handlePrint}>Print Bill</Button>
          </div>
        </Modal>
      )}
    </DefaultLayout>
  );
}

export default Bills;


